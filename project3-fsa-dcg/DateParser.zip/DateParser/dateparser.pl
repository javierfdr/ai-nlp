/*
----------------------------------------------------------------
 Helper predicates for building a complete DCG for date matching
----------------------------------------------------------------
*/

/*
 Defining general regular expression operators
 The following expressions allow to use the operators
 without parenthesis
*/

:- op(100,xf,+).
:- op(100, xf, ?).
:- op(100, xf, *).
:- op(100, xf, .).

/* One or more occurrences of expression*/
+(E) --> E.
+(E) --> E,+(E).

/*One or none ocurrences of expression*/
?(_) --> [].
?(E) --> E.

/*None or any occurences of expression*/
*(_) --> [].
*(E) --> E, *(E).

/* Exactly one ocurrence */
.(E) --> E.

/* birthday - valid atom*/
birthday --> ("birth_day" | "birth day").

/*month in letters */
month_letters --> ("January" | "February" | "March" | "April" 
| "May" | "June" | "July" | "August" | "September" 
| "October" | "November" | "December").

/*month in letters short*/
month_letters_short --> ("Jan" | "Feb" | "Mar" | "Apr" 
| "May" | "Jun" | "Jul" | "Aug" | "Sep" | "Oct" | "Nov" | "Dec").

/* years matcher */
year(X) --> fourDigits(X).

/* validates the expression has exactly four digits*/
four_digits([X,W,Y,Z]) --> 
	digit(X),
	digit_not0(W),
	digit_not0(Y),
	digit_not0(Z).
	
/* Matches any digit*/	
digit(X) --> {code_type(X,digit)}.

/* Matches just digits > 0 
  X is a char list or string literal not an atom
*/
digit_not0(X) --> {
	number_codes(Y,X),	
	Y > 0
}.

/* Match a digit between 1 and 31*/
day(X)--> {
	number_codes(Y,X),
	Y > 0, Y < 32
}.

/* Match a month in numbers*/
month_num([X,Y]) --> digit(X), digit(Y).

/* Surrounded or not with brackets*/
brackets(X) --> X.

/*
------------------------------------
 File parser
------------------------------------
*/

:- use_module(library(pio)).

lines([]) --> call(eos),!.
lines([Line|Lines]) --> line(Line), lines(Lines).

eos([], []).

line([])  --> ( "\n" ; call(eos) ), !.
line([L|Ls]) --> [L], line(Ls).

/*
------------------------------------
 Date parsing and matching grammars
------------------------------------
*/



main :- phrase_from_file(lines(Ls), '/home/usuario/devel/mai/DateParser/examples.txt'),
	match_dates(Ls).
	
match_dates([H|T]):- write(H),nl,match_dates([]).
match_dates([]):- write("The end").

	







    