/*
birth_date	[[1901-09-27]]
birth_date	[[December 13]], [[1952]]
birth_date	18 May, 1959
birth_date	[[March 25]], [[1968]]
birth_date	c. [[1412]]
birth_date	[[1877]]
*/

